<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>E-Commerce</title>
    <!-- swiperjs -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.css" />
    <!-- font awesome start -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- font awesome end -->
    <!-- bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-aFq/bzH65dt+w6FI2ooMVUpc+21e0SRygnTpmBvdBgSdnuTN7QbdgL+OapgHtvPp" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo e(asset('assets/website/style.css')); ?>">
</head>

<body>
    <header class="container-fluid">
        <div class="header1 container">
            <div class="logoDiv">
            <div class="logo">
                <a href="/">
                <img src="<?php echo e(asset('assets/website/image/Click2buy-03.png')); ?>" alt="">
                </a>
            </div>
            <div>
                <a href="./login.html">
                <img class="login_icon" src="<?php echo e(asset('assets/website/image/login_icon.png')); ?>" width="30">
                </a>
            </div>
            <div>
                <a href="./login.html">
                <img class="login_icon" src="<?php echo e(asset('assets/website/image/cart.png')); ?>" width="30">
                </a>
            </div>
            </div>
            <div>
            <form action="" class="search-form">
                <input type="search" name="search" id="searchbox" placeholder="search here">
                <!--<label for="searchbox" class="fas fa-search"></label>-->
                <div class="select-dropdown">
                	<select name="category">
                		<option value="Everything">Everything </option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>"> <?php echo e($category->category_name); ?> </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                	</select>
                </div>
            </form>

            </div>
            <div class="icons">
                <a href="./register.html">
                <button class="btn btn-primary advBtn"> Post an ad</button>
                </a>
            </div>
        </div>
    </header>




    <section class="video-sction container mt100" id="video-sectin">

        <div class="video-parent">
            <iframe class="elementor-video" allowfullscreen="1"
                allow="accelerometer; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                title="Brand New Contemporary Villa in Umm Suqeim | Gulf Sotheby's International Realty"
                src="https://www.youtube.com/embed/kOqcmDa_0i8?controls=0&amp;rel=0&amp;playsinline=1&amp;modestbranding=0&amp;autoplay=1&amp;enablejsapi=1&amp;origin=https%3A%2F%2Fwasit.sa&amp;widgetid=1"
                id="widget2" data-gtm-yt-inspected-8="true" width="640" height="360" frameborder="0"></iframe>
        </div>


    </section>

    <section class="featured-ads container" id="featuredads">

        <div class="card-section">

        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card-design">
                <a href="<?php echo e(route('product.detail', ['slug' => $product->product_slug ])); ?>" >
                <div class="pic-section">
                    <img src="<?php echo e(asset('uploads/products/'.$product->product_thumbnail)); ?>" style="height:200px" alt="">
                </div>
                <div class="card-content-section">
                        <button class="btn cardBtn">
                           <?php echo e($product->product_title); ?>

                        </button>
                    <div class="heading-section">
                       <h6><?php echo e($product->subtitle); ?></h6>
                    </div>

                </div>
                </a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <!-- <div class="card-design">
                <a href="product_detail.html">
                <div class="pic-section">
                    <img src="image/car.jpg" alt="">
                </div>
                <div class="card-content-section">
                        <button class="btn cardBtn">
                           land cruiser
                        </button>
                    <div class="heading-section">
                       <h6>GXR 2021 full GCC</h6>
                    </div>

                </div>
                </a>
            </div>
            <div class="card-design">
                <a href="product_detail.html">
                <div class="pic-section">
                    <img src="image/car.jpg" alt="">
                </div>
                <div class="card-content-section">
                        <button class="btn cardBtn">
                           land cruiser
                        </button>
                    <div class="heading-section">
                       <h6>GXR 2021 full GCC</h6>
                    </div>
                </div>
                </a>
            </div>
            <div class="card-design">
                <a href="product_detail.html">
                <div class="pic-section">
                    <img src="image/car.jpg" alt="">
                </div>
                <div class="card-content-section">
                        <button class="btn cardBtn">
                           land cruiser
                        </button>
                    <div class="heading-section">
                       <h6>GXR 2021 full GCC</h6>
                    </div>
                </div>
                </a>
            </div>
            <div class="card-design">
                <a href="product_detail.html">
                <div class="pic-section">
                    <img src="image/car.jpg" alt="">
                </div>
                <div class="card-content-section">
                        <button class="btn cardBtn">
                           land cruiser
                        </button>
                    <div class="heading-section">
                       <h6>GXR 2021 full GCC</h6>
                    </div>
                </div>
                </a>
            </div>
            <div class="card-design">
                <a href="product_detail.html">
                <div class="pic-section">
                    <img src="image/car.jpg" alt="">
                </div>
                <div class="card-content-section">
                        <button class="btn cardBtn">
                           land cruiser
                        </button>
                    <div class="heading-section">
                       <h6>GXR 2021 full GCC</h6>
                    </div>
                </div>
                </a>
            </div>
            <div class="card-design">
                <a href="product_detail.html">
                <div class="pic-section">
                    <img src="image/car.jpg" alt="">
                </div>
                <div class="card-content-section">
                        <button class="btn cardBtn">
                           land cruiser
                        </button>
                    <div class="heading-section">
                       <h6>GXR 2021 full GCC</h6>
                    </div>
                </div>
                </a>
            </div>
            <div class="card-design">
                <a href="product_detail.html">
                <div class="pic-section">
                    <img src="image/car.jpg" alt="">
                </div>
                <div class="card-content-section">
                        <button class="btn cardBtn">
                           land cruiser
                        </button>
                    <div class="heading-section">
                       <h6>GXR 2021 full GCC</h6>
                    </div>
                </div>
                </a>
            </div>
            <div class="card-design">
                <a href="product_detail.html">
                <div class="pic-section">
                    <img src="image/car.jpg" alt="">
                </div>
                <div class="card-content-section">
                        <button class="btn cardBtn">
                           land cruiser
                        </button>
                    <div class="heading-section">
                       <h6>GXR 2021 full GCC</h6>
                    </div>
                </div>
                </a>
            </div>
            <div class="card-design">
                <a href="product_detail.html">
                <div class="pic-section">
                    <img src="image/car.jpg" alt="">
                </div>
                <div class="card-content-section">
                        <button class="btn cardBtn">
                           land cruiser
                        </button>
                    <div class="heading-section">
                       <h6>GXR 2021 full GCC</h6>
                    </div>
                </div>
                </a>
            </div>
            <div class="card-design">
                <a href="product_detail.html">
                <div class="pic-section">
                    <img src="image/car.jpg" alt="">
                </div>
                <div class="card-content-section">
                        <button class="btn cardBtn">
                           land cruiser
                        </button>
                    <div class="heading-section">
                       <h6>GXR 2021 full GCC</h6>
                    </div>
                </div>
                </a>
            </div>
            <div class="card-design">
                <a href="product_detail.html">
                <div class="pic-section">
                    <img src="image/car.jpg" alt="">
                </div>
                <div class="card-content-section">
                        <button class="btn cardBtn">
                           land cruiser
                        </button>
                    <div class="heading-section">
                       <h6>GXR 2021 full GCC</h6>
                    </div>
                </div>
                </a>
            </div> -->




        </div>


    </section>





    <!--<div class="footer-secion">-->



    <!--    <section>-->
    <!--        <footer id="footer" class="container">-->
                <!--<div class="foot-col-1 footer-ad">-->
                <!--    <div class="logo">-->
                <!--        <a href="#"><img src="image/footer.png"></a>-->
                <!--    </div>-->

                <!--</div>-->


    <!--            <div class="foot-col-2 footer-ad">-->
    <!--                <h4>How To Sell Quickly</h4>-->
    <!--                <ul>-->
    <!--                    <li><a href="#">How to sell quickly</a></li>-->
    <!--                    <li><a href="#">Package subscription</a></li>-->

    <!--                </ul>-->
    <!--            </div>-->

    <!--            <div class="foot-col-3 footer-ad">-->
    <!--                <h4>Informaton</h4>-->
    <!--                <ul>-->
    <!--                    <li><a href="#">About a broker</a></li>-->
    <!--                    <li><a href="#">terms and condition</a></li>-->
    <!--                    <li><a href="#">Prvac Policy</a></li>-->

    <!--                </ul>-->
    <!--            </div>-->


    <!--            <div class="foot-col-4 footer-ad">-->
    <!--                <h4>Help and Support</h4>-->
    <!--                <ul>-->
    <!--                    <li><a href="#">Call us</a></li>-->

    <!--                </ul>-->
    <!--            </div>-->


    <!--        </footer>-->
    <!--    </section>-->
    <!--</div>-->
    <div class="footer">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-sm-4 col-xs-12">
                        <div class="single_footer">
                            <h4>Services</h4>
                            <ul>
                                <li><a href="#">Lorem Ipsum</a></li>
                                <li><a href="#">Simply dummy text</a></li>
                                <li><a href="#">The printing and typesetting </a></li>
                                <li><a href="#">Standard dummy text</a></li>
                                <li><a href="#">Type specimen book</a></li>
                            </ul>
                        </div>
                    </div><!--- END COL -->
                    <div class="col-md-4 col-sm-4 col-xs-12">
                        <div class="single_footer single_footer_address">
                            <h4>Page Link</h4>
                            <ul>
                                <li><a href="#">Lorem Ipsum</a></li>
                                <li><a href="#">Simply dummy text</a></li>
                                <li><a href="#">The printing and typesetting </a></li>
                                <li><a href="#">Standard dummy text</a></li>
                                <li><a href="#">Type specimen book</a></li>
                            </ul>
                        </div>
                    </div><!--- END COL -->
                    <div class="col-md-4 col-sm-4 col-xs-12">
                        <div class="social_profile">
                            <ul>
                                <li><a href="#"><i class="fa fa-facebook-f"></i></a></li>
                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                            </ul>
                        </div>
                    </div><!--- END COL -->
                </div><!--- END ROW -->
                <div class="row">
                    <div class="col-lg-12 col-sm-12 col-xs-12">
                        <p class="copyright">Copyright © 2023 </p>
                    </div><!--- END COL -->
                </div><!--- END ROW -->
            </div><!--- END CONTAINER -->
        </div>




    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/js/bootstrap.bundle.min.js" integrity="sha384-qKXV1j0HvMUeCBQ+QVp7JcfGl760yU08IQ+GpUo5hlbpg51QRiuqHAJz8+BrxE/N" crossorigin="anonymous"></script>
    <script src="<?php echo e(asset('assets/website/app.js')); ?>"></script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\ecommerce-multi-vendor-admin\resources\views/website/index.blade.php ENDPATH**/ ?>