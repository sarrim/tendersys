<header class="container-fluid">
<div class="header1 container">
    <div class="logoDiv">
    <div class="logo">
        <a href="/">
        <img src="<?php echo e(asset('assets/website/image/Click2buy-03.png')); ?>" alt="">
        </a>
    </div>
    <div>
        <a href="<?php echo e(url('login')); ?>">
        <img class="login_icon" src="<?php echo e(asset('assets/website/image/login_icon.png')); ?>" width="30">
        </a>
    </div>
    </div>
    <div>
    <form action="" class="search-form">
        <input type="search" name="" id="searchbox" placeholder="search here">
        <!--<label for="searchbox" class="fas fa-search"></label>-->
        <div class="select-dropdown">
            <select name="category">
                <option value="Everything">Everything </option>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->id); ?>"> <?php echo e($category->category_name); ?> </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </form>

    </div>
    <div class="icons">
        <a href="./register.html">
        <button class="btn btn-primary advBtn"> Post an ad</button>
        </a>
    </div>
</div>
<!--<div class="header2">-->
<!--    <div class="navbar">-->
<!--        <a href="#">Home </a>-->
<!--        <a href="#">Featured </a>-->
<!--        <a href="#">Arrival </a>-->
<!--        <a href="#">Reviews </a>-->
<!--        <a href="#">Contact </a>-->
<!--    </div>-->
<!--</div>-->
</header>
<?php /**PATH C:\xampp\htdocs\ecommerce-multi-vendor-admin\resources\views/_partials/header.blade.php ENDPATH**/ ?>