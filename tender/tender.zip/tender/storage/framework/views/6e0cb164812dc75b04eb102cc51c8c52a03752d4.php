<!-- BEGIN: Vendor JS-->
<script src="https://demos.themeselection.com/sneat-bootstrap-html-laravel-admin-template-free/demo/assets/vendor/libs/jquery/jquery.js?id=c9eab148c98f81221c99ba6da84fdbe2"></script>
<script src="https://demos.themeselection.com/sneat-bootstrap-html-laravel-admin-template-free/demo/assets/vendor/libs/popper/popper.js?id=3b2f93fa0eb2f0ed310a789319de72fc"></script>
<script src="https://demos.themeselection.com/sneat-bootstrap-html-laravel-admin-template-free/demo/assets/vendor/js/bootstrap.js?id=f4406bcd0acdeffbdcca24c2e1033ae6"></script>
<script src="https://demos.themeselection.com/sneat-bootstrap-html-laravel-admin-template-free/demo/assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js?id=2f948c841c6aca9e3a18f6ef2c65b140"></script>
<script src="https://demos.themeselection.com/sneat-bootstrap-html-laravel-admin-template-free/demo/assets/vendor/js/menu.js?id=3421096250c82e0d3760f641a4d2dba0"></script>
<?php echo $__env->yieldContent('vendor-script'); ?>
<!-- END: Page Vendor JS-->
<!-- BEGIN: Theme JS-->
<script src="https://demos.themeselection.com/sneat-bootstrap-html-laravel-admin-template-free/demo/assets/js/main.js?id=0c91cceb5195b308a36d5ac021b16464"></script>

<!-- END: Theme JS-->
<!-- Pricing Modal JS-->
<?php echo $__env->yieldPushContent('pricing-script'); ?>
<!-- END: Pricing Modal JS-->
<!-- BEGIN: Page JS-->
<?php echo $__env->yieldContent('page-script'); ?>
<!-- END: Page JS-->
<?php /**PATH /home/u336971226/domains/solecube.tech/public_html/tender/resources/views/layouts/sections/scripts.blade.php ENDPATH**/ ?>