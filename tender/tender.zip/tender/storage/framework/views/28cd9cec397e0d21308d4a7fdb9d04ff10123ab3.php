<?php $__currentLoopData = $get_messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $messages): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="message-plunch">
    <div class="dash-msg-avatar">
        <img src="https://img.icons8.com/?size=512&id=0lg0kb05hrOz&format=png" alt="">
        <p style="margin-left:10px"> <?php echo e($messages->from_user->username); ?> </p>
        <input type="hidden" name="to_user" value="<?php echo e($user_id); ?>">
    </div>
    <div class="dash-msg-text"><p><?php echo e($messages->message_description); ?></p></div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH /home/u336971226/domains/solecube.tech/public_html/tender/resources/views/website/get_messages.blade.php ENDPATH**/ ?>