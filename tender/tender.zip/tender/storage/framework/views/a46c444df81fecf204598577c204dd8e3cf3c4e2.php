<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ecommerce</title>
    <!-- font awesome start -->
    <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css"> -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- font awesome end -->
    <!-- bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-aFq/bzH65dt+w6FI2ooMVUpc+21e0SRygnTpmBvdBgSdnuTN7QbdgL+OapgHtvPp" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo e(asset('assets/website/style.css')); ?>">
    <!-- JQuery -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
    <!-- JQuery -->
    </head>
    <style>
        outer-parent-section{
  background-color: #f5f7fa;
}

.left-product-section{
  background-color: #fff;
  box-shadow: 0px 0.5rem 1rem  rgba(0, 0, 0, 0.2);
  height: 20rem;
  max-height: 50rem;

}
.parent-product{
  display: grid;
  grid-template-columns: 300px 1fr;
  gap:  2rem;
}

.header-left-product-section{
  border-bottom: 1px solid rgba(0, 0, 0, 0.2);
  padding: 1.5rem;
  font-size: 2.4rem;
  font-weight: bold;
}
.left-content-product-section{
  padding: 3rem 1rem;
}
.left-content-product-section h6{
  font-size: 1.7rem;
  margin-bottom: 2rem;
}
.left-content-product-section p{
  font-size: 1.2rem;
}
.left-content-product-section a{
  color: var(--hovercolor);
}
.inner-first-right-section {
  background-color: #fff;
  box-shadow: 0px 0.5rem 1rem rgba(0, 0, 0, 0.2);
  padding: 1rem 2rem;
}

.image-right-section{
  /* height: 8rem; */
}
.image-right-section img{
  width: 100%;
  height: 100%;
}

.first-category-section{
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  padding: 1rem 0rem;
}
.left-first-category-section{
  display: flex;
align-items: center;
gap: 0.5rem;
flex-wrap: wrap;
}

.outer-left-first-category-section .left-first-category-section i{
  color: var(--hovercolor) !important;
  font-size: 1.2rem;
  padding:  0.5rem;
}
.outer-left-first-category-section .left-first-category-section p{
  font-size: 1.1rem;
}

.right-first-category-btn{
  display: flex;
  flex-direction: row;
  align-items: center;
  gap: 0rem 1rem;
}
.right-first-category-btn button{
  padding: 0.7rem 1.5rem;
  border-radius: 0.5rem;

}
.pump{
background-color: var(--redbtncolor);
color: #fff;
}
.repent{
  background-color: var(--hovercolor);
  color: #fff;
}
.contact-btn{
  margin: 0.5rem 0rem;

}

.contact-btn button{
  background-color: var(--hovercolor);
  color: #fff;
  font-size: 16px;
  padding: 12px 45px;
  -webkit-clip-path: polygon(0 0,100% 0,100% 100%,0 100%,25px 50%);
    clip-path: polygon(0 0,100% 0,100% 100%,0 100%,25px 50%);
}

.category-content{
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 2rem ;
  text-align: left;
}
.right-categoty-content h6{
  position: relative;
  color: #000;
  font-size: 1.7rem;
  font-weight: bold;
}
.right-categoty-content h6::after{
  content: "";
  /* position: absolute;
  bottom: 0;
  width: 2rem;
  height: 0.3rem;
  color: var(--hovercolor);
  background-color: var(--hovercolor);
  display: block; */
  width: 3rem;
  height:0.4rem;
  color: var(--hovercolor);
  background-color: var(--hovercolor);
  display: block;
}
.category-content p{
  font-size: 16px;
  color: #000;
  padding: 0.5rem 0rem;

}
.category-content span{
  font-weight: bold;
}

.main-content p{
  border-top: 1px solid rgba(0,0,0,0.2);
width: max-content;
padding: 1rem;
}

.social-image{
  display: flex;
  gap: 1rem;
}


.map-section{
  background-color: #fff;
  box-shadow: 0px 0.5rem 1rem rgba(0, 0, 0, 0.4);
  margin-top: 2rem;
  padding: 1rem 2rem;
}

.top-map{
  display: grid;
  justify-content: end;
  border-bottom: 0.1rem solid rgba(0, 0, 0, 0.2);
  font-size: 2rem;
  font-weight: bold;
  border-bottom: 0.1rem solid rgba(0, 0, 0, 0.2);
  margin: 1rem 0rem;


}

/* slider */

.flickity-enabled {
    position: relative;
  }

  .flickity-enabled:focus { outline: none; }

  .flickity-viewport {
    overflow: hidden;
    position: relative;
    height: 100%;

  }
  .carousel-main .flickity-viewport{
    /*height: 265px !important;*/
    height: 315px !important;
  }

  .carousel-nav  .flickity-viewport {
    height: 65px;
  }
  .carousel-nav  .flickity-viewport img{
    max-width: 100% !important;
  }
  .carousel-nav svg,.carousel-nav button{
    display: none !important;
  }
  .flickity-slider {
    position: absolute;
    width: 100%;
    height: 100%;
  }
  .previous{
    opacity: 1;
  }
  /* draggable */

  .flickity-enabled.is-draggable {
    -webkit-tap-highlight-color: transparent;
            tap-highlight-color: transparent;
    -webkit-user-select: none;
       -moz-user-select: none;
        -ms-user-select: none;
            user-select: none;
  }

  .flickity-enabled.is-draggable .flickity-viewport {
    cursor: move;
    cursor: -webkit-grab;
    cursor: grab;
  }

  .flickity-enabled.is-draggable .flickity-viewport.is-pointer-down {
    cursor: -webkit-grabbing;
    cursor: grabbing;
  }

  /* ---- previous/next buttons ---- */

  .flickity-prev-next-button {
    position: absolute;
    top: 50%;
    width: 44px;
    height: 44px;
    border: none;
    border-radius: 50%;
    background: white;
    background: hsla(0, 0%, 100%, 0.75);
    cursor: pointer;
    /* vertically center */
    -webkit-transform: translateY(-50%);
            transform: translateY(-50%);
  }

  .flickity-prev-next-button:hover { background: white; }

  .flickity-prev-next-button:focus {
    outline: none;
    box-shadow: 0 0 0 5px #09F;
  }

  .flickity-prev-next-button:active {
    opacity: 0.6;
  }

  .flickity-prev-next-button.previous { left: 10px; }
  .flickity-prev-next-button.next { right: 10px; }

  .flickity-prev-next-button:disabled {
    opacity: 0.3;
    cursor: auto;
  }

  .flickity-prev-next-button svg {
    position: absolute;
    left: 20%;
    top: 20%;
    width: 60%;
    height: 60%;
  }

  .flickity-prev-next-button .arrow {
    fill: #333;
  }


  .carousel {
    background: #FAFAFA;
  }



  .carousel-cell {
    width: 100%;
    height: 504px;
    margin-right: 8px;
    background: transparent;
    border-radius: 5px;
    /* counter-increment: carousel-cell; */
  }

  .carousel-nav .carousel-cell {
    height: 100%;
    width: 120px;
  }

  /* Atelierbram edit */
  .carousel-main img {
    display: block;
    margin: 0 auto;
    max-width: 100%;
  }


  /* The Modal (background) */
.modal {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 99999999999999999; /* Sit on top */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: auto; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
  height: 100%;
  padding-top: 100px;
}

/* Modal Content */
.modal-content {
  background-color: #fefefe;
  margin: auto;
  padding: 20px;
  border: 1px solid #888;
  width: 630px;
height: 230px;
}

/* The Close Button */
.close {
  color: #aaaaaa;
  float: right;
  font-size: 28px;
  font-weight: bold;
  text-align: right;
}

.close:hover,
.close:focus {
  color: #000;
  text-decoration: none;
  cursor: pointer;
}

.modal-dialog {
    min-height: calc(100vh - 60px);
    display: flex;
    flex-direction: column;
    justify-content: center;
    overflow: auto;
}
/* slider */

@media (max-width: 450px) {
  html {
    font-size: 80%;
  }
.carousel-main .flickity-viewport{
    height: 175px !important;
}
.contact-btn button{
    font-size: 15px !important;
    padding: 7px 45px !important;
}



  /* form login logou
  t */
  .inner-form,.name-section{
    display: grid;
    grid-template-columns: 1fr;
  }


  /* product-details -page */
  .parent-product{
    display: grid;
    grid-template-columns: 1fr;
  }
  .first-category-section{
    display: flex;
    flex-direction: column;
  }
  .outer-left-first-category-section .left-first-category-section p{
    font-size: 1rem;
  }
  .category-content{
    display: grid;
    grid-template-columns: 1fr;
  }
  .map-section iframe{
    height: 200px;
  }



}
    </style>
<body>

<?php if ($__env->exists('_partials.header')) echo $__env->make('_partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<div class="outer-parent-section mt100">


    <section class="product-detail container">
<div class="parent-product">



        <div class="left-product-section" style="height:auto;padding:5px" >
            <?php if(isset ($errors) && count($errors) > 0): ?>
                <div class="alert alert-danger" role="alert">
                    <ul class="list-unstyled mb-0">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            
            <div class="header-left-product-section">
                <h5>Update Card Infomation</h5>
            </div>

                <form action="<?php echo e(url('update-profile')); ?>" method="POST" id="checkout-form" >
                    <?php echo csrf_field(); ?>

                    <div class="form-group">
                        <label for="my-input">Name:</label>
                        <input id="my-input" class="form-control" type="text" name="username" value="<?php echo e(Auth::user()->username); ?>">
                    </div>
                    <div class="form-group">
                        <label for="my-input">Email:</label>
                        <input id="my-input" class="form-control" type="text" name="email" value="<?php echo e(Auth::user()->email); ?>">
                    </div>
                    <div class="form-group">
                        <label for="my-input">Contact:</label>
                        <input id="my-input" class="form-control" type="text" name="contact" value="<?php echo e(Auth::user()->contact); ?>">
                    </div>
                    <div class="form-group">
                        <label for="my-input">Card Number:</label>
                        <input id="my-input" class="form-control" type="text" name="card_number" value="<?php echo e(Auth::user()->card_number); ?>">
                    </div>
                    <div class="form-group">
                        <label for="my-input">Card Title:</label>
                        <input id="my-input" class="form-control" type="text" name="card_title" value="<?php echo e(Auth::user()->card_title); ?>">
                    </div>
                    <div class="form-group">
                        <label for="my-input">Exp Year:</label>
                        <input id="my-input" class="form-control" type="text" name="exp_year" value="<?php echo e(Auth::user()->exp_year); ?>">
                    </div>
                    <div class="form-group">
                        <label for="my-input">Exp Month:</label>
                        <input id="my-input" class="form-control" type="text" name="exp_month" value="<?php echo e(Auth::user()->exp_month); ?>">
                    </div>
                    <div class="form-group">
                        <label for="my-input">CVC:</label>
                        <input id="" class="form-control" type="password" name="cvc" value="<?php echo e(Auth::user()->cvc); ?>">
                    </div>
                    <div class="form-group">
                        <label for="my-input">Shipping Address:</label>
                        <textarea class="form-control" name="shipping_address" rows="5" > <?php echo e(Auth::user()->address); ?> </textarea>
                    </div>
                    <input type="hidden" id="billed_aomount" name="billed_aomount">
                    <div class="form-group" style="padding: 10px;">
                        <button type="submit" id="myBtn" class="button-14" >Update</button>
                    </div>

                </form>

        </div>
        <div class="right-product-section">
            <div class="inner-first-right-section">
              <div class="container">


                </div><!-- /.container -->

              <div class="image-option-section">

              </div>


              <div class="contact-btn">
              <?php if(Session::has('message')): ?>
                <div class="alert alert-danger" role="alert">
                    <?php echo e(Session::get('message')); ?>

                </div>
              <?php endif; ?>
              
              <?php if(Session::has('order_message')): ?>
                  <div class="alert alert-success" role="alert">
                      <?php echo e(Session::get('order_message')); ?>

                  </div>
              <?php endif; ?>
                        <!--<button>-->
                        <!--    View Cart-->
                        <!--</button>-->
                </div>

                       <div class="right-categoty-content">
                           <div class="main-content">
                            <table class="table table-responsive">
                                <tbody>
                                    <tr>
                                      <td colspan="" rowspan="" headers=""></td>
                                      <td colspan="" rowspan="" headers="">Available Balance:</td>
                                      <td colspan="3" rowspan="" headers=""> <?php echo e(Auth::user()->available_amount); ?> </td>
                                    </tr>
                                    <tr>
                                      <form action="<?php echo e(url('user/recharge-balance')); ?>" method="get" accept-charset="utf-8">
                                        <td colspan="" rowspan="" headers="">Recharge Balance</td>
                                        <td colspan="" rowspan="" headers=""><input type="number" class="form-control" name="amount"></td>
                                        <td colspan="3" rowspan="" headers=""> <button type="submit" title="" class="btn btn-info btn-sm">Rechange Balance </button> </td>
                                      </form>
                                    </tr>
                                </tbody>
                            </table>
                        </div>


                       </div>
                    </div>

            <!--</div>-->


            <!--<div class="map-section">-->

            <!--    <div class="top-map">-->
            <!--        the site-->
            <!--    </div>-->
            <!--    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d462557.59357265726!2d54.945235471644665!3d25.07709819651367!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3e5f5d05e41699a1%3A0xd46b210fa4a7f8d0!2sSaudi%20Arabian%20Airlines!5e0!3m2!1sen!2s!4v1680377849819!5m2!1sen!2s" width="100%" height="450" style="border:0;" -->
            <!--    allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>  -->
            <!--        </div>-->

        </div>

    </div>




    </section>

</div>
 <div class="footer">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-sm-4 col-xs-12">
                        <div class="single_footer">
                            <h4>Services</h4>
                            <ul>
                                <li><a href="#">Lorem Ipsum</a></li>
                                <li><a href="#">Simply dummy text</a></li>
                                <li><a href="#">The printing and typesetting </a></li>
                                <li><a href="#">Standard dummy text</a></li>
                                <li><a href="#">Type specimen book</a></li>
                            </ul>
                        </div>
                    </div><!--- END COL -->
                    <div class="col-md-4 col-sm-4 col-xs-12">
                        <div class="single_footer single_footer_address">
                            <h4>Page Link</h4>
                            <ul>
                                <li><a href="#">Lorem Ipsum</a></li>
                                <li><a href="#">Simply dummy text</a></li>
                                <li><a href="#">The printing and typesetting </a></li>
                                <li><a href="#">Standard dummy text</a></li>
                                <li><a href="#">Type specimen book</a></li>
                            </ul>
                        </div>
                    </div><!--- END COL -->
                    <div class="col-md-4 col-sm-4 col-xs-12">
                        <div class="social_profile">
                            <ul>
                                <li><a href="#"><i class="fa fa-facebook-f"></i></a></li>
                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                            </ul>
                        </div>
                    </div><!--- END COL -->
                </div><!--- END ROW -->
                <div class="row">
                    <div class="col-lg-12 col-sm-12 col-xs-12">
                        <p class="copyright">Copyright © 2023 </p>
                    </div><!--- END COL -->
                </div><!--- END ROW -->
            </div><!--- END CONTAINER -->
        </div>



<!-- slider cdn -->
    <script src="https://npmcdn.com/flickity@2/dist/flickity.pkgd.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/js/bootstrap.bundle.min.js" integrity="sha384-qKXV1j0HvMUeCBQ+QVp7JcfGl760yU08IQ+GpUo5hlbpg51QRiuqHAJz8+BrxE/N" crossorigin="anonymous"></script>

    <script>

function redirect(){
        var cat = document.getElementById('category').value;
        var keyword = document.getElementById('searchbox').value;

        window.location.href = '/public?search='+keyword+'&category='+cat;
}


// Get the modal
var modal = document.getElementById("myModal");

// Get the button that opens the modal
var btn = document.getElementById("myBtn");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];
var spanClose = document.getElementsByClassName("closeBtn")[0];

// When the user clicks the button, open the modal
btn.onclick = function() {
  modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
  modal.style.display = "none";
}

// When the user clicks on <No>, close the modal
spanClose.onclick = function() {
  modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}


  $(function(){
    $('.confirm').on('click', function(){
      $('#checkout-form')[0].submit();
    })

    $('#billed_aomount').val($('#total_amount').val());

  })

</script>


    </body>

</html>
<?php /**PATH /home/u336971226/domains/solecube.tech/public_html/multi-vendor/resources/views/website/my_profile.blade.php ENDPATH**/ ?>