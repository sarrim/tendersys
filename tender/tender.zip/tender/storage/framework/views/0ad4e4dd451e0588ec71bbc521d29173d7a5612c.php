<header class="container-fluid">
<div class="header1 container">
    <div class="logoDiv">
    <div class="logo">
        <a href="<?php echo e(url('/')); ?>">
        <img src="<?php echo e(asset('assets/website/image/Click2buy-03.png')); ?>" alt="" style="height: 70px;">
        </a>
    </div>
            <?php if(!Auth::user()): ?>
            <div>
                <a href="<?php echo e(url('login')); ?>">
                <img class="login_icon" src="<?php echo e(asset('assets/website/image/login_icon.png')); ?>" width="30">
                </a>
            </div>
            <?php else: ?>
            <div>
                <a href="<?php echo e(url('my-orders')); ?>" title="My Orders">
                    <i class="fa fa-shopping-bag" style="cursor: pointer; color: black;"></i>
                </a>
            </div>
            <div>
                <a href="<?php echo e(url('logout')); ?>" title="Logout">
                    <i class="fa fa-sign-out" style="cursor: pointer; color: black;"></i>
                </a>
            </div>
            <?php endif; ?>
            <div>
                <?php if(!Auth::user()): ?>
                    <a href="<?php echo e(url('login')); ?>">
                <?php else: ?>
                    <a href="<?php echo e(url('view-cart')); ?>">
                <?php endif; ?>
                <img class="login_icon" src="<?php echo e(asset('assets/website/image/cart.png')); ?>" width="30">
                </a>
            </div>
    <!--<div>-->
    <!--    <i class="fa fa-share" onclick="myFunction()" style="padding-right: 10px;cursor: pointer;"></i>-->
    <!--</div>-->
    </div>
    <div class="mobile100">
    <form class="search-form" action="<?php echo e(url('/')); ?>" method="get">
        <input type="search" name="keyword" id="searchbox" placeholder="search here">
        <!--<label for="searchbox" class="fas fa-search"></label>-->
        
    </form>

    </div>
    <div class="icons">
        <a href="<?php echo e(url('vendor/login')); ?>">
        <button class="btn btn-primary advBtn"> Post an ad</button>
        </a>
    </div>
    <?php if(Auth::user()): ?>
    <div class="icons">
        <a href="<?php echo e(url('profile')); ?>" style="font-size: 21px;text-decoration: auto;">
            <i class="fa fa-plus" style="cursor: pointer; color: black; font-size: 25px;"></i> &nbsp; &nbsp; <?php echo e(Auth::user()->available_amount); ?>

        </a>
    </div>
    <?php endif; ?>

</div>
<!--<div class="header2">-->
<!--    <div class="navbar">-->
<!--        <a href="#">Home </a>-->
<!--        <a href="#">Featured </a>-->
<!--        <a href="#">Arrival </a>-->
<!--        <a href="#">Reviews </a>-->
<!--        <a href="#">Contact </a>-->
<!--    </div>-->
<!--</div>-->
</header>
<div class="select-dropdown container">
            <select name="category" id="category" onchange="redirect()" data-placeholder="Choose&hellip;">
                <option value="Everything">Everything </option>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->id); ?>"> <?php echo e($category->category_name); ?> </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
<div class="headerImg"></div>

<?php /**PATH /home/u336971226/domains/solecube.tech/public_html/multi-vendor/resources/views/_partials/header.blade.php ENDPATH**/ ?>