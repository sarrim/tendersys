<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ecommerce</title>
    <!-- font awesome start -->
    <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.2/css/all.min.css"> -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- font awesome end -->
    <!-- bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-aFq/bzH65dt+w6FI2ooMVUpc+21e0SRygnTpmBvdBgSdnuTN7QbdgL+OapgHtvPp" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo e(asset('assets/website/style.css')); ?>">
    <!-- JQuery -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
    <!-- JQuery -->
    </head>
<body>
    <header class="container-fluid">
        <div class="header1 container">
            <div class="logoDiv">
            <div class="logo">
                <a href="<?php echo e(url('/')); ?>">
                <img src="<?php echo e(asset('assets/website/image/Click2buy-03.png')); ?>" alt="">
                </a>    
            </div>
            <?php if(!Auth::user()): ?>
            <div>
                <a href="<?php echo e(url('login')); ?>">
                <img class="login_icon" src="<?php echo e(asset('assets/website/image/login_icon.png')); ?>" width="30">
                </a>
            </div>
            <?php endif; ?>
            <div>
                <i class="fa fa-share" onclick="myFunction()" style="padding-right: 10px;cursor: pointer;"></i>
            </div>
            </div>
            <div class="mobile100">
            <form action="" class="search-form">
                <input type="search" name="" id="searchbox" placeholder="search here">
                <!--<div class="select-dropdown">-->
                <!--<select name="category">-->
                <!--    <option value="Everything">Everything </option>-->
                <!--    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>-->
                <!--        <option value="<?php echo e($category->id); ?>"> <?php echo e($category->category_name); ?> </option>-->
                <!--    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>-->
                <!--</select>-->
                <!--</div>-->
            </form>
            
            </div>
            <div class="icons">
                <a href="<?php echo e(url('vendor/login')); ?>">
                <button class="btn btn-primary advBtn"> Post an ad</button>
                </a>
            </div>
        </div>
    </header>
    <div class="select-dropdown container">
            <select name="category" id="category" onchange="redirect()" data-placeholder="Choose&hellip;">
                <option value="Everything">Everything </option>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->id); ?>"> <?php echo e($category->category_name); ?> </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
<div class="headerImg"></div>
    <section class="parent-form container mt100">
        <form class="inner-form" action="<?php echo e(route('register')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="signup-form">
                <h1 class="clr-primary"> Registeration </h1>
                <?php if(isset ($errors) && count($errors) > 0): ?>
                <div class="alert alert-danger" role="alert">
                    <ul class="list-unstyled mb-0">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>
                <div class="name-section">
                    <div class="user-name">
                    <span>User Name </span>
                    <input type="text" name="username" id="username-register">
                    </div>
                    <!-- <div class="password">
                    <span>Last Name </span>
                    <input type="text" name="last_name" id="login-register">
                    </div> -->
                </div>
        
                <!-- <div class="phone-number">
                    <span>Phone Number </span>
                    <input type="number" name="phone_number" id="username-register">
                </div> -->
        
                <div class="user-email" >
                    <span>Email Address </span>
                    <input type="email" name="email" id="username-register">
                </div>
                
                
                <div class="password" >
                    <span>Password </span>
                    <input type="password" name="password" id="login-register">
                </div>
                
                <div class="password" >
                    <span>Confirm Password </span>
                    <input type="password" name="password_confirmation" id="login-register">
                </div>
                <div class="user" >
                    <span>Sign up As</span>
                    <select class="form-select mt-3" aria-label="Default select example" name="user_type">
                        <option value="3">User</option>
                      <option value="2">Vendor</option>
                    </select>
                </div>
                
                <div class="remember-section"> 
                    <!-- <input type="checkbox" name="" id="reminder">
                    <label for="reminder"> <a>I have read and agree to the <a href="#">Terms and conditions </a>of this website</label> -->
                </div>
        
                <div class="registration-btn d-flex gap-4">
                    <button type="submit">Create account</button>
                    <a href="<?php echo e(url('login')); ?>">
                        <button type="button">Login</button>
                    </a>
                    <!--<a class="btn btn-primary btn-sm" href="login.html">Login</a>-->
                </div>
            </div>
        </form>
    </section>
             <div class="footer">
            <div class="container">     
                <div class="row">                       
                    <div class="col-lg-3 col-sm-4 col-xs-12">
                        <div class="single_footer">
                            <h4>Services</h4>
                            <ul>
                                <li><a href="#">Lorem Ipsum</a></li>
                                <li><a href="#">Simply dummy text</a></li>
                                <li><a href="#">The printing and typesetting </a></li>
                                <li><a href="#">Standard dummy text</a></li>
                                <li><a href="#">Type specimen book</a></li>
                            </ul>
                        </div>
                    </div><!--- END COL --> 
                    <div class="col-md-4 col-sm-4 col-xs-12">
                        <div class="single_footer single_footer_address">
                            <h4>Page Link</h4>
                            <ul>
                                <li><a href="#">Lorem Ipsum</a></li>
                                <li><a href="#">Simply dummy text</a></li>
                                <li><a href="#">The printing and typesetting </a></li>
                                <li><a href="#">Standard dummy text</a></li>
                                <li><a href="#">Type specimen book</a></li>
                            </ul>
                        </div>
                    </div><!--- END COL -->
                    <div class="col-md-4 col-sm-4 col-xs-12">
                        <div class="social_profile">
                            <ul>
                                <li><a href="#"><i class="fa fa-facebook-f"></i></a></li>
                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                            </ul>
                        </div>                          
                    </div><!--- END COL -->         
                </div><!--- END ROW --> 
                <div class="row">
                    <div class="col-lg-12 col-sm-12 col-xs-12">
                        <p class="copyright">Copyright © 2023 </p>
                    </div><!--- END COL -->                 
                </div><!--- END ROW -->                 
            </div><!--- END CONTAINER -->
        </div>


                <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/js/bootstrap.bundle.min.js" integrity="sha384-qKXV1j0HvMUeCBQ+QVp7JcfGl760yU08IQ+GpUo5hlbpg51QRiuqHAJz8+BrxE/N" crossorigin="anonymous"></script>

</body>
</html>

<script>
    function myFunction() {
  // Get the text field
  var copyText = window.location;
   // Copy the text inside the text field
  navigator.clipboard.writeText(copyText);

  alert("Link copied to clipboard");
}
</script><?php /**PATH /home/u336971226/domains/solecube.tech/public_html/multi-vendor/resources/views/website/register.blade.php ENDPATH**/ ?>