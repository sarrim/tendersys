<!-- ============================ Footer Start ================================== -->
					<div class="row">
						<div class="col-md-12">
							<div class="py-3">© 2022 Workplex. Designd By ThemezHub.</div>
						</div>
					</div>
			<!-- ============================ Footer End ================================== -->
						
			<a id="back2Top" class="top-scroll" title="Back to top" href="#"><i class="ti-arrow-up"></i></a>
			

		</div>
		<!-- ============================================================== -->
		<!-- End Wrapper -->
		<!-- ============================================================== -->

		<!-- ============================================================== -->
		<!-- All Jquery -->
		<!-- ============================================================== -->
		<script src="{{ asset('assets/website//js/jquery.min.js') }}"></script>
		<script src="{{ asset('assets/website//js/popper.min.js') }}"></script>
		<script src="{{ asset('assets/website//js/bootstrap.min.js') }}"></script>
		<script src="{{ asset('assets/website//js/slick.js') }}"></script>
		<script src="{{ asset('assets/website//js/slider-bg.js') }}"></script>
		<script src="{{ asset('assets/website//js/smoothproducts.js') }}"></script>
		<script src="{{ asset('assets/website//js/snackbar.min.js') }}"></script>
		<script src="{{ asset('assets/website//js/jQuery.style.switcher.js') }}"></script>
		<script src="{{ asset('assets/website//js/custom.js') }}"></script>
		<!-- ============================================================== -->
		<!-- This page plugins -->
		<!-- ============================================================== -->			

	</body>

<!-- Mirrored from themezhub.net/live-workplex/workplex/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 20 Apr 2023 06:14:04 GMT -->
</html>